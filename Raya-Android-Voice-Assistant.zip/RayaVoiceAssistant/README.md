# Raya Native Android Voice Assistant - Setup Guide

1. Open Android Studio -> Open project in /android directory.
2. Build and run on a connected Android phone:
   ./gradlew installDebug
3. Open Phone Settings -> Accessibility -> Downloaded Services.
4. Turn ON 'Raya Phone Assistant Service'.
5. Grant Microphone permission when prompted.
6. Try saying:
   - "Google Vids kholo aur AI Video select karo"
   - "Prompt box mein ye likho: Best AI tools"
   - "Generate button dabao"
   - "Back jao"
   - "Home par jao"
   - "Emergency Stop"