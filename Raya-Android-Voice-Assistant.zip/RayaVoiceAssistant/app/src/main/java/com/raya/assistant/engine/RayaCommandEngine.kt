package com.raya.assistant.engine

import java.util.Locale

object RayaCommandEngine {
    fun parseCommand(rawText: String, defaultLanguage: String = "hi-IN"): CommandExecutionPlan {
        val lower = rawText.trim().lowercase(Locale.ROOT)

        // Google Vids: "Google Vids kholo aur AI Video select karo"
        if (lower.contains("google vid") && (lower.contains("ai video") || lower.contains("select"))) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "Chrome खोलकर Google Vids पर AI Video शुरू कर रहा हूँ",
                summaryEnglish = "Opening Chrome and selecting AI Video in Google Vids",
                steps = listOf(
                    ActionStep(1, ActionType.OPEN_APP, "Chrome खोल रहा हूँ", "Opening Chrome", targetPackage = "com.android.chrome", waitMillis = 1200L),
                    ActionStep(2, ActionType.OPEN_URL, "Google Vids URL लोड कर रहा हूँ", "Loading Google Vids", targetUrl = "https://vids.google.com", waitMillis = 2000L),
                    ActionStep(3, ActionType.CLICK_ELEMENT, "'AI Video' पर क्लिक कर रहा हूँ", "Clicking AI Video", targetText = "AI Video", waitMillis = 1000L)
                )
            )
        }

        // Prompt input: "Prompt box mein ye likho: [text]"
        if (lower.contains("prompt") && lower.contains("likho")) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "प्रॉम्प्ट बॉक्स में टेक्स्ट डाल रहा हूँ",
                summaryEnglish = "Entering text into prompt box",
                steps = listOf(
                    ActionStep(1, ActionType.CLICK_ELEMENT, "प्रॉम्प्ट इनपुट पर टैप कर रहा हूँ", "Tapping prompt", targetText = "Prompt"),
                    ActionStep(2, ActionType.TYPE_TEXT, "टेक्स्ट टाइप कर रहा हूँ", "Typing text", textToType = rawText.substringAfter("likho:"))
                )
            )
        }

        // "Generate button dabao"
        if (lower.contains("generate") || lower.contains("जनरेट")) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "Generate बटन दबा रहा हूँ",
                summaryEnglish = "Pressing Generate button",
                steps = listOf(
                    ActionStep(1, ActionType.CLICK_ELEMENT, "Generate बटन क्लिक कर रहा हूँ", "Clicking Generate", targetText = "Generate")
                )
            )
        }

        // Navigation: "Back jao", "Home par jao"
        if (lower.contains("back") || lower.contains("बैक")) {
            return CommandExecutionPlan(rawText, defaultLanguage, "वापस जा रहा हूँ", "Navigating back", listOf(ActionStep(1, ActionType.PRESS_BACK, "बैक दबाया", "Pressed back")))
        }
        if (lower.contains("home") || lower.contains("होम")) {
            return CommandExecutionPlan(rawText, defaultLanguage, "होम पर जा रहा हूँ", "Going to home", listOf(ActionStep(1, ActionType.PRESS_HOME, "होम दबाया", "Pressed home")))
        }

        // Risky actions: delete, send message, payment -> Require confirmation
        if (lower.contains("delete") || lower.contains("message bhejo") || lower.contains("pay")) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "जोखिम भरा एक्शन - यूज़र की पुष्टि आवश्यक",
                summaryEnglish = "Risky action - User confirmation required",
                requiresUserConfirmation = true,
                steps = listOf(ActionStep(1, ActionType.CONFIRM_RISKY_ACTION, "अनुमति माँगी जा रही है", "Awaiting confirmation", riskLevel = RiskLevel.RISKY))
            )
        }

        return CommandExecutionPlan(rawText, defaultLanguage, "कमांड समझ में नहीं आया", "Unrecognized command", emptyList())
    }
}