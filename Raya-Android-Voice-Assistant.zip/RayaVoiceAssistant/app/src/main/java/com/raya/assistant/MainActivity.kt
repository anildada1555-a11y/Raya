package com.raya.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.raya.assistant.service.RayaAccessibilityService
import com.raya.assistant.speech.RayaSpeechManager

class MainActivity : ComponentActivity() {
    private lateinit var speechManager: RayaSpeechManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speechManager = RayaSpeechManager(this) { command ->
            // Receives voice command in Hindi/Hinglish
        }
        setContent {
            RayaAssistantScreen(
                speechManager = speechManager,
                onOpenAccessibilitySettings = { /* opens settings */ }
            )
        }
    }
}