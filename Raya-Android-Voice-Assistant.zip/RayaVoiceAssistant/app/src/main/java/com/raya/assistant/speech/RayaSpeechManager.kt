package com.raya.assistant.speech

import android.content.Context
import android.speech.RecognitionListener
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class RayaSpeechManager(context: Context, val onRecognized: (String) -> Unit) : RecognitionListener, TextToSpeech.OnInitListener {
    // Manages Android SpeechRecognizer for hi-IN and en-IN with fallback TTS
    override fun onInit(status: Int) {}
    override fun onReadyForSpeech(params: android.os.Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {}
    override fun onResults(results: android.os.Bundle?) {}
    override fun onPartialResults(partialResults: android.os.Bundle?) {}
    override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
}