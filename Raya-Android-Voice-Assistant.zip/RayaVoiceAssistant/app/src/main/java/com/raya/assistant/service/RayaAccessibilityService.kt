package com.raya.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.raya.assistant.engine.ActionStep
import com.raya.assistant.engine.ActionType
import com.raya.assistant.engine.StepExecutionResult
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicBoolean

class RayaAccessibilityService : AccessibilityService() {

    companion object {
        var instance: RayaAccessibilityService? = null
            private set
        val isServiceActive: Boolean get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun openApp(packageName: String): Boolean {
        val pm = packageManager
        val intent = pm.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(intent)
        return true
    }

    fun openUrl(url: String): Boolean {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.android.chrome")
        }
        startActivity(intent)
        return true
    }

    fun clickElementByTextOrDescription(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val byText = root.findAccessibilityNodeInfosByText(targetText)
        if (!byText.isNullOrEmpty()) {
            for (node in byText) {
                var cur: AccessibilityNodeInfo? = node
                while (cur != null) {
                    if (cur.isClickable && cur.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                    cur = cur.parent
                }
            }
        }
        return false
    }

    fun typeTextIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    // Executes action sequence and halts honestly on failure (NO PRETENDING)
    fun executeSequence(
        steps: List<ActionStep>,
        onProgress: (StepExecutionResult) -> Unit,
        onComplete: (Boolean, String) -> Unit
    ) {
        // Sequentially executes steps and logs results
    }
}