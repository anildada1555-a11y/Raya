package com.raya.assistant.engine

import java.util.Locale

enum class ActionType {
    OPEN_APP,
    OPEN_URL,
    CLICK_ELEMENT,
    TYPE_TEXT,
    PRESS_BACK,
    PRESS_HOME,
    CONFIRM_RISKY_ACTION
}

enum class RiskLevel {
    SAFE,
    RISKY
}

data class ActionStep(
    val stepNumber: Int,
    val actionType: ActionType,
    val descriptionHindi: String,
    val descriptionEnglish: String,
    val targetPackage: String? = null,
    val targetUrl: String? = null,
    val targetText: String? = null,
    val textToType: String? = null,
    val waitMillis: Long = 500L,
    val riskLevel: RiskLevel = RiskLevel.SAFE
)

data class CommandExecutionPlan(
    val originalVoiceText: String,
    val detectedLanguage: String,
    val summaryHindi: String,
    val summaryEnglish: String,
    val steps: List<ActionStep>,
    val requiresUserConfirmation: Boolean = false
)

data class StepExecutionResult(
    val step: ActionStep,
    val success: Boolean,
    val message: String
)

object RayaCommandEngine {
    fun parseCommand(rawText: String, defaultLanguage: String = "hi-IN"): CommandExecutionPlan {
        val lower = rawText.trim().lowercase(Locale.ROOT)

        if (lower.contains("google vid") && (lower.contains("ai video") || lower.contains("select"))) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "Chrome खोलकर Google Vids पर AI Video शुरू कर रहा हूँ",
                summaryEnglish = "Opening Chrome and selecting AI Video in Google Vids",
                steps = listOf(
                    ActionStep(1, ActionType.OPEN_APP, "Chrome खोल रहा हूँ", "Opening Chrome", targetPackage = "com.android.chrome", waitMillis = 1200L),
                    ActionStep(2, ActionType.OPEN_URL, "Google Vids URL लोड कर रहा हूँ", "Loading Google Vids", targetUrl = "https://vids.google.com", waitMillis = 2000L),
                    ActionStep(3, ActionType.CLICK_ELEMENT, "AI Video पर क्लिक कर रहा हूँ", "Clicking AI Video", targetText = "AI Video", waitMillis = 1000L)
                )
            )
        }

        if (lower.contains("prompt") && lower.contains("likho")) {
            val text = rawText.substringAfter("likho:", "").trim().ifEmpty {
                rawText.substringAfter("likho", "").trim()
            }
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "प्रॉम्प्ट बॉक्स में टेक्स्ट डाल रहा हूँ",
                summaryEnglish = "Entering text into prompt box",
                steps = listOf(
                    ActionStep(1, ActionType.CLICK_ELEMENT, "प्रॉम्प्ट इनपुट पर टैप कर रहा हूँ", "Tapping prompt", targetText = "Prompt"),
                    ActionStep(2, ActionType.TYPE_TEXT, "टेक्स्ट टाइप कर रहा हूँ", "Typing text", textToType = text)
                )
            )
        }

        if (lower.contains("generate") || lower.contains("जनरेट")) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "Generate बटन दबा रहा हूँ",
                summaryEnglish = "Pressing Generate button",
                steps = listOf(
                    ActionStep(1, ActionType.CLICK_ELEMENT, "Generate बटन क्लिक कर रहा हूँ", "Clicking Generate", targetText = "Generate")
                )
            )
        }

        if (lower.contains("back") || lower.contains("बैक")) {
            return CommandExecutionPlan(rawText, defaultLanguage, "वापस जा रहा हूँ", "Navigating back", listOf(ActionStep(1, ActionType.PRESS_BACK, "बैक दबाया", "Pressed back")))
        }

        if (lower.contains("home") || lower.contains("होम")) {
            return CommandExecutionPlan(rawText, defaultLanguage, "होम पर जा रहा हूँ", "Going to home", listOf(ActionStep(1, ActionType.PRESS_HOME, "होम दबाया", "Pressed home")))
        }

        if (lower.contains("delete") || lower.contains("message bhejo") || lower.contains("pay")) {
            return CommandExecutionPlan(
                originalVoiceText = rawText,
                detectedLanguage = defaultLanguage,
                summaryHindi = "जोखिम भरा एक्शन - यूज़र की पुष्टि आवश्यक",
                summaryEnglish = "Risky action - User confirmation required",
                requiresUserConfirmation = true,
                steps = listOf(ActionStep(1, ActionType.CONFIRM_RISKY_ACTION, "अनुमति माँगी जा रही है", "Awaiting confirmation", riskLevel = RiskLevel.RISKY))
            )
        }

        return CommandExecutionPlan(rawText, defaultLanguage, "कमांड समझ में नहीं आया", "Unrecognized command", emptyList())
    }
}
