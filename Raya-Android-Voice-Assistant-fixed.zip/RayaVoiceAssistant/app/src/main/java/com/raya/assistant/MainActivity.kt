package com.raya.assistant

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raya.assistant.speech.RayaSpeechManager

class MainActivity : ComponentActivity() {
    private lateinit var speechManager: RayaSpeechManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        speechManager = RayaSpeechManager(this) { command ->
            // Voice command is received here.
        }

        setContent {
            RayaAssistScreen(
                onOpenAccessibilitySettings = {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            )
        }
    }
}

@Composable
fun RayaAssistScreen(onOpenAccessibilitySettings: () -> Unit) {
    MaterialTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Raya",
                style = MaterialTheme.typography.headlineLarge
            )
            Text(
                text = "Native Android Voice Assistant",
                modifier = Modifier.padding(top = 8.dp, bottom = 24.dp)
            )
            Button(onClick = onOpenAccessibilitySettings) {
                Text("Accessibility ON करें")
            }
        }
    }
}
