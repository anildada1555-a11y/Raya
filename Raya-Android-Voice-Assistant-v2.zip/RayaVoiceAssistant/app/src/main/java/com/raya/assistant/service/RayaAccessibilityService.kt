package com.raya.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.raya.assistant.engine.ActionStep
import com.raya.assistant.engine.ActionType
import com.raya.assistant.engine.StepExecutionResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale

class RayaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: RayaAccessibilityService? = null
            private set

        val isServiceActive: Boolean
            get() = instance != null
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var executionJob: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        executionJob?.cancel()
        serviceScope.cancel()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
    override fun onInterrupt() {
        stopCurrentExecution()
    }

    fun stopCurrentExecution() {
        executionJob?.cancel()
        executionJob = null
    }

    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun openApp(packageName: String): Boolean {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            startActivity(launchIntent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun openUrl(url: String): Boolean {
        val chromeIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.android.chrome")
        }

        return try {
            if (packageManager.resolveActivity(chromeIntent, 0) != null) {
                startActivity(chromeIntent)
                true
            } else {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(browserIntent)
                true
            }
        } catch (_: Exception) {
            false
        }
    }

    fun clickElementByTextOrDescription(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val wanted = normalize(targetText)
        if (wanted.isBlank()) return false

        val candidates = mutableListOf<AccessibilityNodeInfo>()
        collectNodes(root, candidates)

        val exact = candidates.firstOrNull { node ->
            normalize(node.text?.toString()) == wanted ||
                normalize(node.contentDescription?.toString()) == wanted
        }

        val partial = exact ?: candidates.firstOrNull { node ->
            normalize(node.text?.toString()).contains(wanted) ||
                normalize(node.contentDescription?.toString()).contains(wanted)
        }

        return partial?.let { clickNodeOrParent(it) } == true
    }

    fun typeTextIntoFocusedField(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false

        val args = Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }

        return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun executeSequence(
        steps: List<ActionStep>,
        onProgress: (StepExecutionResult) -> Unit,
        onComplete: (Boolean, String) -> Unit
    ) {
        stopCurrentExecution()

        if (steps.isEmpty()) {
            onComplete(false, "कोई executable action नहीं मिला")
            return
        }

        executionJob = serviceScope.launch {
            try {
                for (step in steps) {
                    if (step.actionType == ActionType.CONFIRM_RISKY_ACTION) {
                        onProgress(StepExecutionResult(step, false, "यह action confirmation मांगता है"))
                        onComplete(false, "Confirmation required")
                        return@launch
                    }

                    val success = executeWithRetry(step)
                    val message = if (success) {
                        step.descriptionHindi
                    } else {
                        "Action failed: ${step.descriptionEnglish}"
                    }

                    onProgress(StepExecutionResult(step, success, message))

                    if (!success) {
                        onComplete(false, message)
                        return@launch
                    }

                    if (step.waitMillis > 0) delay(step.waitMillis)
                }

                onComplete(true, "सभी actions सफलतापूर्वक पूरे हुए")
            } catch (_: CancellationException) {
                onComplete(false, "Raya execution stopped")
            } catch (e: Exception) {
                onComplete(false, "Execution error: ${e.message ?: "unknown"}")
            } finally {
                executionJob = null
            }
        }
    }

    private suspend fun executeWithRetry(step: ActionStep): Boolean {
        repeat(6) { attempt ->
            val success = withContext(Dispatchers.Main.immediate) {
                when (step.actionType) {
                    ActionType.OPEN_APP -> step.targetPackage?.let(::openApp) == true
                    ActionType.OPEN_URL -> step.targetUrl?.let(::openUrl) == true
                    ActionType.CLICK_ELEMENT -> step.targetText?.let(::clickElementByTextOrDescription) == true
                    ActionType.TYPE_TEXT -> step.textToType?.let(::typeTextIntoFocusedField) == true
                    ActionType.PRESS_BACK -> pressBack()
                    ActionType.PRESS_HOME -> pressHome()
                    ActionType.CONFIRM_RISKY_ACTION -> false
                }
            }

            if (success) return true
            if (attempt < 5) delay(450)
        }
        return false
    }

    private fun collectNodes(
        node: AccessibilityNodeInfo,
        output: MutableList<AccessibilityNodeInfo>
    ) {
        output += node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectNodes(child, output)
        }
    }

    private fun clickNodeOrParent(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        repeat(8) {
            val n = current ?: return false
            if (n.isVisibleToUser && n.isClickable &&
                n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) {
                return true
            }
            current = n.parent
        }
        return false
    }

    private fun normalize(value: String?): String =
        value.orEmpty()
            .trim()
            .lowercase(Locale.ROOT)
            .replace(Regex("\\s+"), " ")
}
