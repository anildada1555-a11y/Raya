package com.raya.assistant.engine

import java.util.Locale

enum class ActionType {
    OPEN_APP,
    OPEN_URL,
    CLICK_ELEMENT,
    TYPE_TEXT,
    PRESS_BACK,
    PRESS_HOME,
    CONFIRM_RISKY_ACTION
}

enum class RiskLevel {
    SAFE,
    RISKY
}

data class ActionStep(
    val stepNumber: Int,
    val actionType: ActionType,
    val descriptionHindi: String,
    val descriptionEnglish: String,
    val targetPackage: String? = null,
    val targetUrl: String? = null,
    val targetText: String? = null,
    val textToType: String? = null,
    val waitMillis: Long = 700L,
    val riskLevel: RiskLevel = RiskLevel.SAFE
)

data class CommandExecutionPlan(
    val originalVoiceText: String,
    val detectedLanguage: String,
    val summaryHindi: String,
    val summaryEnglish: String,
    val steps: List<ActionStep>,
    val requiresUserConfirmation: Boolean = false
)

data class StepExecutionResult(
    val step: ActionStep,
    val success: Boolean,
    val message: String
)

object RayaCommandEngine {

    private const val CHROME = "com.android.chrome"
    private const val VIDS_URL = "https://vids.google.com/"

    fun parseCommand(rawText: String, defaultLanguage: String = "hi-IN"): CommandExecutionPlan {
        val raw = rawText.trim()
        val lower = raw.lowercase(Locale.ROOT)

        if (lower.isBlank()) {
            return emptyPlan(raw, defaultLanguage)
        }

        if (lower.contains("emergency stop") || lower.contains("stop raya") || lower == "stop" || lower.contains("रोक दो")) {
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "Raya को रोक रहा हूँ", "Stopping Raya",
                listOf(ActionStep(1, ActionType.CONFIRM_RISKY_ACTION, "सभी चल रहे एक्शन रोकें", "Stop current execution"))
            )
        }

        if (lower.contains("google vids") || lower.contains("google vid")) {
            val steps = mutableListOf<ActionStep>()
            var n = 1

            steps += ActionStep(n++, ActionType.OPEN_APP, "Chrome खोल रहा हूँ", "Opening Chrome", targetPackage = CHROME, waitMillis = 1200)

            if (lower.contains("ai video") || lower.contains("a.i. video") || lower.contains("video")) {
                steps += ActionStep(n++, ActionType.OPEN_URL, "Google Vids खोल रहा हूँ", "Opening Google Vids", targetUrl = VIDS_URL, waitMillis = 2500)
                steps += ActionStep(n, ActionType.CLICK_ELEMENT, "AI Video ढूँढकर क्लिक कर रहा हूँ", "Finding and clicking AI Video", targetText = "AI Video", waitMillis = 1000)
            } else {
                steps += ActionStep(n, ActionType.OPEN_URL, "Google Vids खोल रहा हूँ", "Opening Google Vids", targetUrl = VIDS_URL, waitMillis = 2500)
            }

            return CommandExecutionPlan(
                raw, defaultLanguage,
                "Google Vids खोल रहा हूँ", "Opening Google Vids",
                steps
            )
        }

        if (lower.contains("chrome") && (lower.contains("khol") || lower.contains("open"))) {
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "Chrome खोल रहा हूँ", "Opening Chrome",
                listOf(ActionStep(1, ActionType.OPEN_APP, "Chrome खोल रहा हूँ", "Opening Chrome", targetPackage = CHROME, waitMillis = 1200))
            )
        }

        if (lower.contains("prompt") && (lower.contains("likho") || lower.contains("type") || lower.contains("enter"))) {
            val text = extractTextAfterPrompt(raw)
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "प्रॉम्प्ट बॉक्स में टेक्स्ट डाल रहा हूँ", "Entering prompt text",
                listOf(
                    ActionStep(1, ActionType.CLICK_ELEMENT, "Prompt बॉक्स ढूँढ रहा हूँ", "Finding prompt box", targetText = "Prompt", waitMillis = 500),
                    ActionStep(2, ActionType.TYPE_TEXT, "टेक्स्ट लिख रहा हूँ", "Typing prompt text", textToType = text)
                )
            )
        }

        if (lower.contains("generate") || lower.contains("जनरेट")) {
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "Generate बटन दबा रहा हूँ", "Clicking Generate",
                listOf(ActionStep(1, ActionType.CLICK_ELEMENT, "Generate बटन ढूँढ रहा हूँ", "Finding Generate", targetText = "Generate"))
            )
        }

        if (lower.contains("back") || lower.contains("बैक") || lower.contains("पीछे")) {
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "वापस जा रहा हूँ", "Going back",
                listOf(ActionStep(1, ActionType.PRESS_BACK, "Back दबा रहा हूँ", "Pressing Back"))
            )
        }

        if (lower.contains("home") || lower.contains("होम")) {
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "होम पर जा रहा हूँ", "Going Home",
                listOf(ActionStep(1, ActionType.PRESS_HOME, "होम पर जा रहा हूँ", "Going Home"))
            )
        }

        if (lower.contains("delete") || lower.contains("pay") || lower.contains("payment") ||
            lower.contains("message bhejo") || lower.contains("send message") || lower.contains("call ")) {
            return CommandExecutionPlan(
                raw, defaultLanguage,
                "यह संवेदनशील एक्शन है, पहले पुष्टि चाहिए",
                "This action requires confirmation",
                listOf(ActionStep(1, ActionType.CONFIRM_RISKY_ACTION, "यूज़र की पुष्टि आवश्यक", "User confirmation required", riskLevel = RiskLevel.RISKY)),
                requiresUserConfirmation = true
            )
        }

        return emptyPlan(raw, defaultLanguage)
    }

    private fun extractTextAfterPrompt(raw: String): String {
        val match = Regex("(?i)prompt\\s*(?:box\\s*)?(?:mein|me)?\\s*(?:ye\\s*)?(?:likho|type|enter)\\s*[:：-]?\\s*(.*)$")
            .find(raw)
        return match?.groupValues?.getOrNull(1)?.trim().orEmpty()
    }

    private fun emptyPlan(raw: String, language: String): CommandExecutionPlan =
        CommandExecutionPlan(
            raw, language,
            "कमांड समझ में नहीं आया", "Command not recognized",
            emptyList()
        )
}
