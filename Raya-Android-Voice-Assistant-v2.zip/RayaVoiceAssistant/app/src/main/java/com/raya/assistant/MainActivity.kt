package com.raya.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.raya.assistant.engine.RayaCommandEngine
import com.raya.assistant.service.RayaAccessibilityService
import com.raya.assistant.speech.RayaSpeechManager

class MainActivity : ComponentActivity() {

    private lateinit var speechManager: RayaSpeechManager

    private var status by mutableStateOf("Raya तैयार है")
    private var lastCommand by mutableStateOf("कोई command नहीं")

    private val microphonePermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            status = if (granted) "Microphone permission मिल गया" else "Microphone permission denied"
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        speechManager = RayaSpeechManager(
            context = this,
            onRecognized = ::handleVoiceCommand,
            onStatus = { status = it }
        )

        setContent {
            RayaAssistScreen(
                status = status,
                lastCommand = lastCommand,
                serviceActive = RayaAccessibilityService.isServiceActive,
                onListen = ::startListening,
                onStop = {
                    RayaAccessibilityService.instance?.stopCurrentExecution()
                    speechManager.stopListening()
                    status = "Raya stopped"
                },
                onAccessibility = {
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                }
            )
        }
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            microphonePermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        speechManager.startListening()
    }

    private fun handleVoiceCommand(command: String) {
        lastCommand = command
        val plan = RayaCommandEngine.parseCommand(command)

        if (command.lowercase().contains("emergency stop") ||
            command.lowercase().contains("stop raya")
        ) {
            RayaAccessibilityService.instance?.stopCurrentExecution()
            status = "Raya stopped"
            speechManager.speak("राया रोक दिया")
            return
        }

        if (plan.steps.isEmpty()) {
            status = plan.summaryHindi
            speechManager.speak("कमांड समझ में नहीं आया")
            return
        }

        val service = RayaAccessibilityService.instance
        if (service == null) {
            status = "पहले Accessibility Service ON करें"
            speechManager.speak("पहले accessibility service ऑन करें")
            return
        }

        status = plan.summaryHindi
        speechManager.speak(plan.summaryHindi)

        service.executeSequence(
            steps = plan.steps,
            onProgress = { result ->
                status = if (result.success) {
                    "✓ ${result.message}"
                } else {
                    "✗ ${result.message}"
                }
            },
            onComplete = { success, message ->
                status = if (success) "✓ $message" else "✗ $message"
            }
        )
    }

    override fun onDestroy() {
        speechManager.shutdown()
        super.onDestroy()
    }
}

@androidx.compose.runtime.Composable
private fun RayaAssistScreen(
    status: String,
    lastCommand: String,
    serviceActive: Boolean,
    onListen: () -> Unit,
    onStop: () -> Unit,
    onAccessibility: () -> Unit
) {
    MaterialTheme {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text("Raya", style = MaterialTheme.typography.headlineLarge)
            Text("Native Android Voice Assistant")

            Text(
                if (serviceActive) "Accessibility: ON" else "Accessibility: OFF",
                style = MaterialTheme.typography.titleMedium
            )

            Text("Status: $status")
            Text("Last command: $lastCommand")

            Button(onClick = onListen) {
                Text("🎤 Command बोलें")
            }

            OutlinedButton(onClick = onStop) {
                Text("STOP")
            }

            OutlinedButton(onClick = onAccessibility) {
                Text("Accessibility Settings")
            }

            Text(
                "Examples:\n" +
                    "• Chrome kholo\n" +
                    "• Google Vids kholo\n" +
                    "• Google Vids kholo aur AI Video select karo\n" +
                    "• Prompt mein ye likho: Best AI tools\n" +
                    "• Generate button dabao\n" +
                    "• Back karo\n" +
                    "• Home par jao"
            )
        }
    }
}
