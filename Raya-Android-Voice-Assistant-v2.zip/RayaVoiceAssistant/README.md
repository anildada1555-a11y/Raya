# Raya Voice Assistant v2

Phone-first native Android prototype.

## Build
Use Gradle 8.10+ with JDK 17.

## Setup on phone
1. Install the debug APK.
2. Open Raya.
3. Grant Microphone permission.
4. Open Accessibility Settings.
5. Enable "Raya Phone Assistant Service".
6. Return to Raya and use the microphone button.

## Supported commands
- Chrome kholo
- Google Vids kholo
- Google Vids kholo aur AI Video select karo
- Prompt mein ye likho: ...
- Generate button dabao
- Back karo
- Home par jao
- Emergency Stop

## Important
UI automation depends on the accessibility tree exposed by the target app/browser. A visible label may change, so a click can legitimately fail instead of pretending that it succeeded.
