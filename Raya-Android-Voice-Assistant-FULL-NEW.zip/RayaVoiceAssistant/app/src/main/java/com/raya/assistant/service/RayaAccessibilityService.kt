package com.raya.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.raya.assistant.engine.ActionStep
import com.raya.assistant.engine.ActionType
import com.raya.assistant.engine.RiskLevel
import com.raya.assistant.engine.StepExecutionResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale

class RayaAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: RayaAccessibilityService? = null
            private set

        val isServiceActive: Boolean
            get() = instance != null
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var job: Job? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onDestroy() {
        stopCurrentExecution()
        scope.cancel()
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit

    override fun onInterrupt() {
        stopCurrentExecution()
    }

    fun stopCurrentExecution() {
        job?.cancel()
        job = null
    }

    fun pressBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)

    fun pressHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)

    fun openApp(packageName: String): Boolean {
        val intent = packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return runCatching {
            startActivity(intent)
            true
        }.getOrDefault(false)
    }

    fun openUrl(url: String): Boolean {
        val chrome = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.android.chrome")
        }
        return runCatching {
            if (packageManager.resolveActivity(chrome, 0) != null) {
                startActivity(chrome)
            } else {
                val browser = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(browser)
            }
            true
        }.getOrDefault(false)
    }

    fun executeSequence(
        steps: List<ActionStep>,
        onProgress: (StepExecutionResult) -> Unit,
        onComplete: (Boolean, String) -> Unit
    ) {
        stopCurrentExecution()
        if (steps.isEmpty()) {
            onComplete(false, "कोई action नहीं मिला")
            return
        }

        job = scope.launch {
            try {
                for (step in steps) {
                    if (step.risk == RiskLevel.CONFIRMATION_REQUIRED) {
                        onProgress(StepExecutionResult(step, false, "इस action के लिए confirmation जरूरी है"))
                        onComplete(false, "Confirmation required")
                        return@launch
                    }

                    if (step.type == ActionType.STOP) {
                        onComplete(true, "Raya stopped")
                        return@launch
                    }

                    val success = executeWithRetry(step)
                    val message = if (success) step.description else "Action नहीं हुआ: ${step.description}"
                    onProgress(StepExecutionResult(step, success, message))

                    if (!success) {
                        onComplete(false, message)
                        return@launch
                    }

                    if (step.waitAfterMs > 0) delay(step.waitAfterMs)
                }
                onComplete(true, "सभी actions पूरे हो गए")
            } catch (_: CancellationException) {
                onComplete(false, "Raya execution stopped")
            } catch (t: Throwable) {
                onComplete(false, "Error: ${t.message ?: "unknown"}")
            } finally {
                job = null
            }
        }
    }

    private suspend fun executeWithRetry(step: ActionStep): Boolean {
        repeat(8) { attempt ->
            val ok = when (step.type) {
                ActionType.OPEN_APP -> step.targetPackage?.let(::openApp) == true
                ActionType.OPEN_URL -> step.targetUrl?.let(::openUrl) == true
                ActionType.CLICK_ELEMENT -> clickAny(step.targetTexts)
                ActionType.TYPE_TEXT -> typeText(step.text.orEmpty())
                ActionType.PRESS_BACK -> pressBack()
                ActionType.PRESS_HOME -> pressHome()
                ActionType.STOP -> true
            }
            if (ok) return true
            if (attempt < 7) delay(500)
        }
        return false
    }

    private fun clickAny(targets: List<String>): Boolean {
        if (targets.isEmpty()) return false
        for (root in candidateRoots()) {
            for (target in targets) {
                val node = findBestNode(root, target)
                if (node != null && clickNodeOrParent(node)) return true
            }
        }
        return false
    }

    private fun typeText(text: String): Boolean {
        if (text.isBlank()) return false

        val focused = candidateRoots().asSequence()
            .mapNotNull { it.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) }
            .firstOrNull { it.isEditable }

        if (focused != null && setText(focused, text)) return true

        val editable = candidateRoots().asSequence()
            .flatMap { root -> allNodes(root).asSequence() }
            .firstOrNull { it.isVisibleToUser && it.isEditable }

        if (editable != null) {
            editable.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (setText(editable, text)) return true
        }
        return false
    }

    private fun setText(node: AccessibilityNodeInfo, text: String): Boolean {
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findBestNode(root: AccessibilityNodeInfo, target: String): AccessibilityNodeInfo? {
        val wanted = normalize(target)
        if (wanted.isBlank()) return null
        val nodes = allNodes(root)

        fun value(node: AccessibilityNodeInfo): List<String> = listOf(
            node.text?.toString(),
            node.contentDescription?.toString(),
            node.viewIdResourceName?.toString()
        ).mapNotNull { it?.let(::normalize) }.filter { it.isNotBlank() }

        nodes.firstOrNull { node ->
            node.isVisibleToUser && value(node).any { it == wanted }
        }?.let { return it }

        nodes.firstOrNull { node ->
            node.isVisibleToUser && value(node).any { it.contains(wanted) || wanted.contains(it) }
        }?.let { return it }

        return null
    }

    private fun clickNodeOrParent(start: AccessibilityNodeInfo): Boolean {
        var node: AccessibilityNodeInfo? = start
        repeat(10) {
            val current = node ?: return false
            if (current.isVisibleToUser && current.isClickable &&
                current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            ) return true
            node = current.parent
        }
        return false
    }

    private fun candidateRoots(): List<AccessibilityNodeInfo> {
        val result = mutableListOf<AccessibilityNodeInfo>()
        rootInActiveWindow?.let(result::add)
        runCatching { windows.mapNotNullTo(result) { it.root } }
        return result.distinctBy { it.windowId }
    }

    private fun allNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val result = ArrayList<AccessibilityNodeInfo>()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.add(root)
        while (stack.isNotEmpty()) {
            val node = stack.removeLast()
            result += node
            for (i in 0 until node.childCount) {
                node.getChild(i)?.let(stack::add)
            }
        }
        return result
    }

    private fun normalize(value: String): String =
        value.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")
}
