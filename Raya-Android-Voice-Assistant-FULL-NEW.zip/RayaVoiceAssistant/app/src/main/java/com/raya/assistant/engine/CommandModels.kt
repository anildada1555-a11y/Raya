package com.raya.assistant.engine

enum class ActionType {
    OPEN_APP,
    OPEN_URL,
    CLICK_ELEMENT,
    TYPE_TEXT,
    PRESS_BACK,
    PRESS_HOME,
    STOP
}

enum class RiskLevel { SAFE, CONFIRMATION_REQUIRED }

data class ActionStep(
    val number: Int,
    val type: ActionType,
    val description: String,
    val targetPackage: String? = null,
    val targetUrl: String? = null,
    val targetTexts: List<String> = emptyList(),
    val text: String? = null,
    val waitAfterMs: Long = 700L,
    val risk: RiskLevel = RiskLevel.SAFE
)

data class CommandExecutionPlan(
    val original: String,
    val summary: String,
    val steps: List<ActionStep>,
    val requiresConfirmation: Boolean = false
)

data class StepExecutionResult(
    val step: ActionStep,
    val success: Boolean,
    val message: String
)
