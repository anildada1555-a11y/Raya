package com.raya.assistant.engine

import java.util.Locale

object RayaCommandEngine {
    private const val CHROME = "com.android.chrome"
    private const val VIDS_URL = "https://vids.google.com/"

    fun parseCommand(input: String): CommandExecutionPlan {
        val raw = input.trim()
        val s = normalize(raw)
        if (s.isBlank()) return empty(raw)

        if (isStopCommand(s)) {
            return CommandExecutionPlan(
                raw,
                "Raya रोक रहा हूँ",
                listOf(ActionStep(1, ActionType.STOP, "Raya रोक दिया"))
            )
        }

        if (isBack(s)) return plan(raw, "Back दबा रहा हूँ", ActionType.PRESS_BACK)
        if (isHome(s)) return plan(raw, "Home पर जा रहा हूँ", ActionType.PRESS_HOME)

        if (isGenerate(s)) {
            return CommandExecutionPlan(
                raw,
                "Generate दबा रहा हूँ",
                listOf(ActionStep(1, ActionType.CLICK_ELEMENT, "Generate दबाया", targetTexts = listOf("Generate", "Create", "जनरेट", "Create video", "Submit")))
            )
        }

        if (containsPromptCommand(s)) {
            val prompt = extractPrompt(raw)
            if (prompt.isBlank()) return empty(raw, "Prompt का text नहीं मिला")
            return CommandExecutionPlan(
                raw,
                "Prompt में text डाल रहा हूँ",
                listOf(
                    ActionStep(1, ActionType.CLICK_ELEMENT, "Prompt box ढूँढ रहा हूँ", targetTexts = listOf("Prompt", "Describe your video", "What do you want to create", "Enter a prompt", "Type a prompt"), waitAfterMs = 300),
                    ActionStep(2, ActionType.TYPE_TEXT, "Prompt text लिख रहा हूँ", text = prompt, waitAfterMs = 500)
                )
            )
        }

        if (isGoogleVids(s)) {
            val wantsAiVideo = s.contains("ai video") || s.contains("a i video") || s.contains("ai-video")
            val steps = mutableListOf<ActionStep>()
            steps += ActionStep(1, ActionType.OPEN_APP, "Chrome खोल रहा हूँ", targetPackage = CHROME, waitAfterMs = 1000)
            steps += ActionStep(2, ActionType.OPEN_URL, "Google Vids खोल रहा हूँ", targetUrl = VIDS_URL, waitAfterMs = 3000)
            if (wantsAiVideo) {
                steps += ActionStep(3, ActionType.CLICK_ELEMENT, "AI Video चुन रहा हूँ", targetTexts = listOf("AI Video", "AI video", "Create with AI", "Video"), waitAfterMs = 1000)
            }
            return CommandExecutionPlan(raw, if (wantsAiVideo) "Google Vids और AI Video खोल रहा हूँ" else "Google Vids खोल रहा हूँ", steps)
        }

        if (isChrome(s)) {
            return CommandExecutionPlan(
                raw,
                "Chrome खोल रहा हूँ",
                listOf(ActionStep(1, ActionType.OPEN_APP, "Chrome खोल रहा हूँ", targetPackage = CHROME, waitAfterMs = 1000))
            )
        }

        if (looksSensitive(s)) {
            return CommandExecutionPlan(
                raw,
                "यह संवेदनशील action है, पुष्टि जरूरी है",
                listOf(ActionStep(1, ActionType.STOP, "Confirmation required", risk = RiskLevel.CONFIRMATION_REQUIRED)),
                requiresConfirmation = true
            )
        }

        return empty(raw)
    }

    private fun plan(raw: String, summary: String, type: ActionType) =
        CommandExecutionPlan(raw, summary, listOf(ActionStep(1, type, summary)))

    private fun isGoogleVids(s: String) =
        s.contains("google vids") || s.contains("google vid") || s.contains("google video")

    private fun isChrome(s: String) =
        s.contains("chrome") && (s.contains("open") || s.contains("khol") || s.contains("खोल"))

    private fun isBack(s: String) =
        s == "back" || s.contains("back karo") || s.contains("back kar") || s.contains("बैक") || s.contains("पीछे जाओ")

    private fun isHome(s: String) =
        s == "home" || s.contains("home par") || s.contains("home pe") || s.contains("home jao") || s.contains("होम")

    private fun isGenerate(s: String) =
        s.contains("generate") || s.contains("जनरेट") || s.contains("create video")

    private fun containsPromptCommand(s: String) =
        s.contains("prompt") && (s.contains("likh") || s.contains("type") || s.contains("enter") || s.contains("daal") || s.contains("डाल") || s.contains("लिख"))

    private fun extractPrompt(raw: String): String {
        val patterns = listOf(
            Regex("(?is)prompt(?:\\s+box)?\\s*(?:mein|me|में)?\\s*(?:ye|यह|this)?\\s*(?:likho|likh do|type karo|type|enter karo|daalo|dalo|डालो|लिखो)\\s*[:：-]?\\s*(.*)$"),
            Regex("(?is)prompt\\s*[:：-]\\s*(.*)$")
        )
        for (pattern in patterns) {
            val value = pattern.find(raw)?.groupValues?.getOrNull(1)?.trim()
            if (!value.isNullOrBlank()) return value
        }
        return ""
    }

    private fun isStopCommand(s: String) =
        s == "stop" || s == "रोक दो" || s == "रोक" || s.contains("emergency stop") || s.contains("stop raya") || s.contains("raya stop")

    private fun looksSensitive(s: String) =
        s.contains("payment") || s.contains("pay karo") || s.contains("delete") || s.contains("call karo") || s.contains("message bhejo") || s.contains("send message")

    private fun normalize(value: String) =
        value.lowercase(Locale.ROOT).trim().replace(Regex("\\s+"), " ")

    private fun empty(raw: String, summary: String = "कमांड समझ में नहीं आया") =
        CommandExecutionPlan(raw, summary, emptyList())
}
