package com.raya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.raya.assistant.engine.RayaCommandEngine
import com.raya.assistant.service.RayaAccessibilityService
import com.raya.assistant.speech.RayaSpeechManager

class MainActivity : Activity() {

    private lateinit var speech: RayaSpeechManager
    private lateinit var statusText: TextView
    private lateinit var serviceText: TextView
    private lateinit var commandText: TextView
    private lateinit var manualInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()

        speech = RayaSpeechManager(
            context = this,
            onResult = ::runVoiceCommand,
            onStatus = { status -> runOnUiThread { setStatus(status) } }
        )

        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
        }
    }

    override fun onResume() {
        super.onResume()
        updateServiceState()
    }

    private fun buildUi() {
        val scroll = ScrollView(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(28))
        }

        val title = TextView(this).apply {
            text = "Raya"
            textSize = 32f
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title, lp())

        val subtitle = TextView(this).apply {
            text = "Native Android Voice Assistant"
            textSize = 17f
        }
        root.addView(subtitle, lp(0, 4))

        serviceText = TextView(this).apply { textSize = 16f }
        root.addView(serviceText, lp(0, 18))

        statusText = TextView(this).apply {
            textSize = 16f
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(0xFFEFEAF7.toInt())
        }
        root.addView(statusText, lp())

        commandText = TextView(this).apply {
            text = "Last command: none"
            textSize = 15f
        }
        root.addView(commandText, lp(0, 14))

        val listen = Button(this).apply {
            text = "🎤  Command बोलें"
            setOnClickListener { startListening() }
        }
        root.addView(listen, lp(0, 16))

        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener {
                RayaAccessibilityService.instance?.stopCurrentExecution()
                speech.stopListening()
                setStatus("Raya stopped")
            }
        }
        root.addView(stop, lp(0, 8))

        val accessibility = Button(this).apply {
            text = "Accessibility ON करें"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }
        root.addView(accessibility, lp(0, 8))

        manualInput = EditText(this).apply {
            hint = "Test command लिखें..."
            minLines = 2
            gravity = Gravity.TOP
        }
        root.addView(manualInput, lp(0, 20))

        val runManual = Button(this).apply {
            text = "Typed Command चलाएँ"
            setOnClickListener {
                val text = manualInput.text?.toString().orEmpty().trim()
                if (text.isNotBlank()) runVoiceCommand(text)
            }
        }
        root.addView(runManual, lp(0, 8))

        val examples = TextView(this).apply {
            text = "Commands:\n" +
                "• Chrome kholo\n" +
                "• Google Vids kholo\n" +
                "• Google Vids kholo aur AI Video select karo\n" +
                "• Prompt mein ye likho: A boy walking in a forest\n" +
                "• Generate button dabao\n" +
                "• Back karo\n" +
                "• Home par jao\n" +
                "• Emergency Stop"
            textSize = 15f
        }
        root.addView(examples, lp(0, 22))

        scroll.addView(root)
        setContentView(scroll)
        setStatus("Raya तैयार है")
        updateServiceState()
    }

    private fun startListening() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQUEST_MIC)
            return
        }
        speech.startListening()
    }

    private fun runVoiceCommand(command: String) {
        runOnUiThread {
            commandText.text = "Last command: $command"
            val plan = RayaCommandEngine.parseCommand(command)

            if (plan.steps.any { it.type.name == "STOP" }) {
                RayaAccessibilityService.instance?.stopCurrentExecution()
                setStatus("Raya stopped")
                speech.speak("राया रोक दिया")
                return@runOnUiThread
            }

            if (plan.steps.isEmpty()) {
                setStatus(plan.summary)
                speech.speak("कमांड समझ में नहीं आया")
                return@runOnUiThread
            }

            if (plan.requiresConfirmation) {
                setStatus("इस action के लिए confirmation जरूरी है")
                speech.speak("इस action के लिए confirmation जरूरी है")
                return@runOnUiThread
            }

            val service = RayaAccessibilityService.instance
            if (service == null) {
                setStatus("पहले Accessibility Service ON करें")
                speech.speak("पहले accessibility service ऑन करें")
                return@runOnUiThread
            }

            setStatus(plan.summary)
            service.executeSequence(
                steps = plan.steps,
                onProgress = { result ->
                    setStatus(if (result.success) "✓ ${result.message}" else "✗ ${result.message}")
                },
                onComplete = { success, message ->
                    setStatus(if (success) "✓ $message" else "✗ $message")
                }
            )
        }
    }

    private fun updateServiceState() {
        if (!::serviceText.isInitialized) return
        serviceText.text = if (RayaAccessibilityService.isServiceActive) {
            "Accessibility: ON ✓"
        } else {
            "Accessibility: OFF"
        }
    }

    private fun setStatus(value: String) {
        if (::statusText.isInitialized) statusText.text = "Status: $value"
        updateServiceState()
    }

    private fun lp(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        if (::speech.isInitialized) speech.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_MIC = 7001
    }
}
