package com.raya.assistant.speech

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import java.util.Locale

class RayaSpeechManager(
    context: Context,
    private val onResult: (String) -> Unit,
    private val onStatus: (String) -> Unit
) : RecognitionListener, TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private val recognizer: SpeechRecognizer? =
        if (SpeechRecognizer.isRecognitionAvailable(appContext)) {
            SpeechRecognizer.createSpeechRecognizer(appContext).also {
                it.setRecognitionListener(this)
            }
        } else null

    private val tts = TextToSpeech(appContext, this)
    private var ttsReady = false

    fun startListening() {
        val speech = recognizer
        if (speech == null) {
            onStatus("Speech recognition उपलब्ध नहीं है")
            return
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
        }

        onStatus("🎤 सुन रहा हूँ...")
        runCatching { speech.startListening(intent) }
            .onFailure { onStatus("Speech start error: ${it.message ?: "unknown"}") }
    }

    fun stopListening() {
        runCatching { recognizer?.cancel() }
    }

    fun speak(text: String) {
        if (!ttsReady || text.isBlank()) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "raya-${System.nanoTime()}")
    }

    fun shutdown() {
        runCatching { recognizer?.destroy() }
        runCatching { tts.stop() }
        runCatching { tts.shutdown() }
    }

    override fun onInit(status: Int) {
        ttsReady = status == TextToSpeech.SUCCESS
        if (!ttsReady) return
        val result = tts.setLanguage(Locale("hi", "IN"))
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            tts.language = Locale.ENGLISH
        }
    }

    override fun onReadyForSpeech(params: Bundle?) { onStatus("बोलिए...") }
    override fun onBeginningOfSpeech() { onStatus("सुन रहा हूँ...") }
    override fun onRmsChanged(rmsdB: Float) = Unit
    override fun onBufferReceived(buffer: ByteArray?) = Unit
    override fun onEndOfSpeech() { onStatus("समझ रहा हूँ...") }
    override fun onPartialResults(partialResults: Bundle?) = Unit
    override fun onEvent(eventType: Int, params: Bundle?) = Unit

    override fun onError(error: Int) {
        onStatus("Speech error: $error")
    }

    override fun onResults(results: Bundle?) {
        val values = results
            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            .orEmpty()
        val text = values.firstOrNull { it.isNotBlank() }.orEmpty()
        if (text.isBlank()) onStatus("Command नहीं मिली") else onResult(text)
    }
}
