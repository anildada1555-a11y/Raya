# Raya Voice Assistant 3.0

A clean phone-first native Android voice assistant.

## Architecture
- Native Kotlin Android app
- Android SpeechRecognizer for Hindi/Hinglish voice input
- TextToSpeech for Hindi feedback
- AccessibilityService for Back/Home, app launch, UI click and text entry
- Deterministic command parser, no fake success messages
- No Compose, so there is no Compose Compiler/Kotlin compatibility problem

## Main commands
- Chrome kholo
- Google Vids kholo
- Google Vids kholo aur AI Video select karo
- Prompt mein ye likho: ...
- Generate button dabao
- Back karo
- Home par jao
- Emergency Stop

## Setup
1. Install the debug APK.
2. Grant microphone permission.
3. Android Settings > Accessibility > Raya Phone Assistant > ON.
4. Return to Raya.
5. Test `Chrome kholo` first, then `Google Vids kholo`.

## Important
Accessibility automation depends on the UI tree exposed by the target app/browser. Labels can change, and a real failure is reported instead of being treated as success.
